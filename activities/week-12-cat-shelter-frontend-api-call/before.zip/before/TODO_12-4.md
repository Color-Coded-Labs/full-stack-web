# CRUD Front End Implementation Activity:

## Read (do this one first!):
* when I click "get all cats" I want the cats to be fetched and then displayed on the dom.