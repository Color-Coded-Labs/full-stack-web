const apiUrl = 'localhost:3000'; 

function getAllCats() {
    // Implement logic to call the API endpoint to get all cats
    // Use fetch or any AJAX library you prefer
}

function addCat() {
    // Implement logic to call the API endpoint to add a cat
    // Use fetch or any AJAX library you prefer
    const catName = document.getElementById('catName').value;
    const catAge = document.getElementById('catAge').value;

    // Check if name and age are provided
    if (catName && catAge) {
        // Implement logic to call the API endpoint to add a cat
        // Use fetch or any AJAX library you prefer
    } else {
        alert('Please provide both name and age for the cat.');
    }
}

function updateCat() {
    // Implement logic to call the API endpoint to update a cat
    // Use fetch or any AJAX library you prefer
}

function adoptCat() {
    // Implement logic to call the API endpoint to remove a cat
    // Use fetch or any AJAX library you prefer
}